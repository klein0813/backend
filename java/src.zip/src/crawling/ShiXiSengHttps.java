package crawling;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class ShiXiSengHttps {
	private static class X509TrustAnyManager implements X509TrustManager {

		@Override
		public void checkClientTrusted(X509Certificate[] chain, String authType)
				throws CertificateException {
			// TODO Auto-generated method stub

		}
	 
		@Override
		public void checkServerTrusted(X509Certificate[] chain, String authType)
				throws CertificateException {
			// TODO Auto-generated method stub
	 
		}
	 
		@Override
		public X509Certificate[] getAcceptedIssuers() {
			// TODO Auto-generated method stub
			return null;
		}

	}

	private static class TrustAnyHostnameVerifier implements HostnameVerifier {
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }

	public static InputStream HttpsGetRequest(String url) throws IOException, KeyManagementException, NoSuchAlgorithmException {
		   SSLContext sc = SSLContext.getInstance("SSL");
           sc.init(null, new TrustManager[] { new X509TrustAnyManager() },
                    new java.security.SecureRandom());

		  URL u = new URL(null, url, new sun.net.www.protocol.https.Handler());
          //��һ��URL���ӣ������пͻ��˷�����Դ
          HttpsURLConnection httpconn = (HttpsURLConnection) u.openConnection();
          httpconn.setSSLSocketFactory(sc.getSocketFactory());
          httpconn.setHostnameVerifier(new TrustAnyHostnameVerifier());
          httpconn.setDoOutput(true);
          httpconn.connect();

          //httpconn.getInputStream(),http����ŷ���
          return httpconn.getInputStream();
	}

	public static String ConvertInputStream2String(InputStream inputStream) throws IOException {
        StringBuilder result = new StringBuilder();
        BufferedReader in = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));

        String line;

        //��һ���������е��ļ������ζ�ȡ����
        while ((line = in.readLine()) != null) {
            result.append(line);
        }

        if (in != null) {
            in.close();
        }

        return result.toString();
	}
}
