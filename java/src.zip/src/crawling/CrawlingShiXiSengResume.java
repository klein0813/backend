package crawling;


import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.WebClient;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URLEncoder;

import org.json.JSONObject;
 
public class CrawlingShiXiSengResume {

    public static String tempResumePath = "tempResume.pdf";

    /**
     * �˷����������ڡ�ʵϰɮ�����ʼ�����������ַ��Ӧ����ҳ
     * ����emailAttachUrl����ȡ���������ַ���email_auth
     * ����hrapi�����ܻ�ȡdlv_id��dlv_id��Ϊ�����ٴε���hrapi�����ɻ�ȡ����
     * @param emailAttachUrl
     * @return
     */
    public static boolean getResume(String emailAttachUrl) {
        String emailAuth = emailAttachUrl.substring(emailAttachUrl.lastIndexOf("/") + 1);
        String emailDecodeUrl = "https://hrapi.shixiseng.com/email_decode?email_auth=" + URLEncoder.encode(emailAuth);

        try {
            String emailDecode = ShiXiSengHttps.ConvertInputStream2String(ShiXiSengHttps.HttpsGetRequest(emailDecodeUrl));
            if (emailDecode != null) {
                JSONObject object = new JSONObject(emailDecode);

                if ("success".equals(object.get("msg"))) {
                    JSONObject data = (JSONObject) object.get("data");
                    String dlvId = data.get("dlv_id").toString();

                    String iframeUrl = "https://hrapi.shixiseng.com/api/v2/resume/action?dlv_id=" + dlvId + "&lan=chinese&only_data=false";
                    InputStream result = getResumePDFStream(iframeUrl);

                    FileOutputStream out = new FileOutputStream(tempResumePath);
                    int outData;
                    while((outData = result.read()) != -1) {
                        out.write(outData);
                    }
                    result.close();
                    out.close();

                    return true;
                }
            }

            return false;
        } catch (Exception e) {
//            TODO: ����log
            e.printStackTrace();
            return false;
        }
    }

    /**
     * https://hrapi.shixiseng.com/api/v2/resume/action?dlv_id=dlvId&lan=chinese&only_data=false"
     * @param url
     * @return PDF �� InputStream 
     * @throws FailingHttpStatusCodeException
     * @throws MalformedURLException
     * @throws IOException
     * 2019/8/13
     */
    private static InputStream getResumePDFStream(String url) throws FailingHttpStatusCodeException, MalformedURLException, IOException {

//        �õ����������
        WebClient webClient = new WebClient(BrowserVersion.CHROME);
//        ʹ֮��ִ��https����
        webClient.getOptions().setUseInsecureSSL(true);
//        ����JS
        webClient.getOptions().setJavaScriptEnabled(true);
//        ������CSS
        webClient.getOptions().setCssEnabled(false);
        webClient.getOptions().setActiveXNative(false);
//        ����֧��AJAX
        webClient.setAjaxController(new NicelyResynchronizingAjaxController());
//        ��JSִ�г�����ʱ���Ƿ��׳��쳣
        webClient.getOptions().setThrowExceptionOnScriptError(false);
//        ��HTTP��״̬��200ʱ�Ƿ��׳��쳣
        webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
//        ���á��������������ʱʱ��
        webClient.getOptions().setTimeout(100000);
        Page page = webClient.getPage(url);
//        ����һ������JavaScript��ʱ��
        webClient.waitForBackgroundJavaScript(100000);

        InputStream pdfInputStream = page.getWebResponse().getContentAsStream();

        return pdfInputStream;
    }
}
