package crawling;

import java.util.Map;

import analysis.AnalyResume;


public class Main {

    public static void main(String[] args) {

        String emailAttachUrl = "https://hr.shixiseng.com/new/#/email/view/B_zrauq71u1wLC3JQc2yynZYA_BYTxWH7Bh1TDCYd85b9DnudKeKGb0s9a4o6zMgnPWXpaybPdqg7ENcTLULzg==";
        boolean success = CrawlingShiXiSengResume.getResume(emailAttachUrl);
        System.out.println(success);

        if (success) {
            Map<String, String> analyResult = AnalyResume.analy(CrawlingShiXiSengResume.tempResumePath);

            if (analyResult == null) {
                System.out.println("����ʧ��");
                return;
            }

            for (Map.Entry<String, String> entry: analyResult.entrySet()) {
                System.out.println(entry.getKey().concat("��").concat(entry.getValue()));
            }
        }
    }

}
