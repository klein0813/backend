package analysis;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.pdfbox.io.RandomAccessFile;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.xwpf.usermodel.BodyElementType;
import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTR;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class AnalyResume {

    private static StringBuffer strBuf = new StringBuffer();
    private static BufferedWriter out;

    private static String paragraphSeparator = "~~";
    private static String runSeparator = "##";
    private static String nodeSeparator = "&&";
    private static String[] normalSeparator = new String[] {" ", "-", "_"};

    private static String phoneReg = "1[3456789]\\d-{0,1}\\d{4}-{0,1}\\d{4}";

    private static String suffix;

    public static Map<String, String> analy(String filePath) {

        suffix = filePath.substring(filePath.lastIndexOf("."));
        try {
            if (".doc".equals(suffix)) {
                return analysisDoc(filePath);
            } else if (".docx".equals(suffix)) {
                return analysisDocx(filePath);
            } else if (".pdf".equals(suffix)) {
                return analysisPDF(filePath);
            } else {
//                TODO: ����log: ���Ͳ�֧��
                return null;
            }
        } catch (IOException e) {
//            TODO: ����log
            e.printStackTrace();
            return null;
        }
    }

    private static void writeFile(String output) {
        File writeName = new File("output.txt");

        try {
            writeName.createNewFile();
            FileWriter writer = new FileWriter(writeName);
            out = new BufferedWriter(writer);
            out.write(output);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static Map<String, String> analysisPDF(String filePath) throws InvalidPasswordException, IOException {
        File file = new File(filePath);
        // �½�һ��PDF����������
        PDFParser parser = new PDFParser(new RandomAccessFile(file,"r"));
        // ��PDF�ļ����н���
        parser.parse();
        // ��ȡ������õ���PDF�ĵ�����
        PDDocument pdfdocument = parser.getPDDocument();
        // �½�һ��PDF�ı�������
        PDFTextStripper stripper = new PDFTextStripper();
        //sort����Ϊtrue �����н��ж�ȡ��Ĭ����false
        stripper .setSortByPosition(false);
        // ��PDF�ĵ������а����ı�
        String result = stripper.getText(pdfdocument);

        writeFile(result);

        return analyData(filePath, result);
    }

    private static Map<String, String> analysisDocx(String filePath) throws FileNotFoundException, IOException {
        XWPFDocument doc = new XWPFDocument(new FileInputStream(filePath));

        for (IBodyElement iBodyElement :  doc.getBodyElements()){

            if (iBodyElement.getElementType().equals(BodyElementType.PARAGRAPH)) {

                XWPFParagraph xwpfParagraph = (XWPFParagraph)iBodyElement;
                analyParagraph(xwpfParagraph);
            } else if (iBodyElement.getElementType().equals(BodyElementType.TABLE)) {

                XWPFTable xwpfTable = (XWPFTable)iBodyElement;
                for(XWPFTableRow row : xwpfTable.getRows())
                {
                    for(XWPFTableCell cell : row.getTableCells())
                    {
                        for(XWPFParagraph xwpfParagraph : cell.getParagraphs())
                        {
                            analyParagraph(xwpfParagraph);
                        }
                    }
                }
            }
        }

        String str = strBuf.toString();

        writeFile(str);

        return analyData(filePath, str);
    }

    private static Map<String, String> analysisDoc(String filePath) throws FileNotFoundException, IOException {
        HWPFDocument doc = new HWPFDocument(new FileInputStream(filePath));
        String str = doc.getDocumentText();

        writeFile(str);

        return analyData(filePath, str);
    }

    public static String analysisFileName (String fileName) {
        fileName = fileName.substring(fileName.lastIndexOf("\\") + 1).replaceAll(suffix, "");
        String[] fileNameSplit = null;

        /**
         * ��ȡ�������
         * ���ݣ���style split fileName �����ʱ
         */
        for (String style : normalSeparator) {
            String reg = style + "|��|��|[|]";

            if (fileNameSplit != null) {
                String[] tempSplit = fileName.split(reg);
                if (fileNameSplit.length < tempSplit.length) {
                    fileNameSplit = tempSplit;
                }
            } else {
                fileNameSplit = fileName.split(reg);
            }
        }

        List<String> names = new ArrayList<String>();

        for (String splitUnit : fileNameSplit) {
            if (NameJudgment.isName(splitUnit)) {
                names.add(splitUnit);
            }
        }

        /**
         * ��������ȡ����û�л������������ϣ�����ȡʧ��
         */
        if (names.size() == 1) {
            return names.get(0);
        }

        return null;
    }

    private static Map<String, String> analyData(String filePath, String str) throws IOException {
        str = filterNoisyData(str);

        String regSeparator = "(" + runSeparator + ")*" + "(" + nodeSeparator + ")*" + "(" + runSeparator + ")*";
        String emailReg = "[a-zA-Z0-9_]+" + regSeparator + "@" + regSeparator + "[a-zA-Z0-9]+(\\.[a-zA-Z]+){1,3}";
        String nameReg = "��(\\s)*" + regSeparator + "��(\\s)*(:)*(��)*" + regSeparator + "[\\u4e00-\\u9fa5]+";

        String email = reg(str, emailReg);
        String name = reg(str, nameReg);

        str = str.replaceAll("#|&", "");
        email = email == null ? reg(str, emailReg) : email.replaceAll("#|&", "");

        if (email != null) {
            str = str.replaceAll(email, "");
        }

        String phone = reg(str, phoneReg);
        phone = phone == null ? reg(email, phoneReg) : phone;

        if (name != null) {
            String[] temps = name.replaceAll("#|&", "").split("��| |:");
            name = temps[temps.length - 1];
        } else {
            String nameFromAnalysisfileName = analysisFileName(filePath);
            if (nameFromAnalysisfileName != null && str.replaceAll("#|&", "").contains(nameFromAnalysisfileName)) {
                name = nameFromAnalysisfileName;
            }
        }

        if (name == null) {
            /*
             * ������ĵ�����������ֶ�����ģ��
             * 1,����ǰ��
             * 2,��ְ����ǰ��
             * 3,�������
             */
            Map<String, String> regNameMap = new HashMap<String, String>();
            regNameMap.put("[\\u4e00-\\u9fa5]+(" + paragraphSeparator + ")*��ְ����", "(" + paragraphSeparator + ")*��ְ����");
            regNameMap.put("[\\u4e00-\\u9fa5]+(" + paragraphSeparator + ")*[1-9]{2}��", "(" + paragraphSeparator + ")*[1-9]{2}��");
            regNameMap.put("[\\u4e00-\\u9fa5]+(" + paragraphSeparator + ")*(��|Ů)", "(" + paragraphSeparator + ")*(��|Ů)");
            regNameMap.put("@[a-zA-Z0-9]+(\\.[a-zA-Z]+){1,3}[\\u4e00-\\u9fa5]+" + paragraphSeparator, "@[a-zA-Z0-9]+(\\.[a-zA-Z]+){1,3}|" + paragraphSeparator);
            for (Map.Entry<String, String> entry: regNameMap.entrySet()) {
                name = reg(str, entry.getKey());
                if (name != null) {
                    name = name.replaceAll(entry.getValue(), "");
                    name = NameJudgment.isName(name) ? name : null;
                    break;
                }
            }
        }

        Map<String, String> resultMap = new HashMap<String, String>();
        resultMap.put("name", name);
        resultMap.put("phone", phone);
        resultMap.put("email", email);

        return resultMap;
    }

    private static String filterNoisyData(String data) {
        data = handleSpecialCharacters(data);
        /*
         * ��������֤����
         * 100000 19000101 000[0Xx] ~ 999999 20991231 999[9Xx]
         * 100000 000101 000 ~ 999999 991231 999
         */
        String regIdNumber = "([1-9]\\d{5}(19|20)\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx])|([1-9]\\d{5}\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{2})";
        data = data.replaceAll(regIdNumber, " ");

//        ���˿հ׺���ռλ��
        data = data.replaceAll("\\u3000", " ");

        return data;
    }

    private static String reg(String str, String reg) {
         Matcher matcher = Pattern.compile(reg).matcher(str);
         if (matcher.find()) {
             return matcher.group();
         }
         return null;
    }

    private static String handleSpecialCharacters(String str) {
        if (str != null) {
            char[] charArray = str.toCharArray();
            for (int i = 0; i < charArray.length; i ++) {
                char c = charArray[i];
                if (c < 31) {
                    charArray[i] = 32;
                }
            }

            return String.valueOf(charArray);
        }

        return null;
    }

//    �����ӽڵ�
    private static void analyParagraph(XWPFParagraph xwpfParagraph) {
        if (xwpfParagraph.getParagraphText().length() > 0) {
            strBuf.append(xwpfParagraph.getParagraphText());
            return;
        }
        List<XWPFRun> xwpfruns = xwpfParagraph.getRuns();

        for (XWPFRun xwpfRun : xwpfruns) {
            CTR ctr = xwpfRun.getCTR(); 
            Node node = ctr.getDomNode();
            getTextFromNodes(node);
            strBuf.append(runSeparator);
        }
        strBuf.append(paragraphSeparator);
    }

    private static void getTextFromNodes(Node node) {
        String name = node.getNodeName();

        if ("w:t".equals(name)) {
            String text = node.getFirstChild().getNodeValue();
            strBuf.append(text);
            strBuf.append(nodeSeparator);
        } else if (node.hasChildNodes()) {
            NodeList nodes = node.getChildNodes();
            for (int i = 0; i <nodes.getLength(); i++) {
                getTextFromNodes(nodes.item(i));
            }
        }
    }
}
