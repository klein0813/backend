package analysis;

import java.util.Map;

public class Main {

//    private static String filePath = "C:\\Users\\klein.zhou\\Desktop\\resume\\1.docx";
    private static String filePath = "tempResume.pdf";

    public static void main(String[] args) {
    	Map<String, String> analyResult = AnalyResume.analy(filePath);
    	
    	if (analyResult == null) {
    		System.out.println("����ʧ��");
    		return;
    	}
    	
    	for (Map.Entry<String, String> entry: analyResult.entrySet()) {
    		System.out.println(entry.getKey().concat("��").concat(entry.getValue()));
    	}
    }
}
